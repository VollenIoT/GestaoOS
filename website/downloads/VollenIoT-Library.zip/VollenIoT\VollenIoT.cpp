// =============================================================================
// VollenIoT.cpp - Implementação da biblioteca VollenIoT
// =============================================================================
//
// ATENÇÃO: As credenciais MQTT abaixo são do desenvolvedor e ficam
// embutidas na biblioteca. O usuário final não precisa configurá-las.
// =============================================================================

#include "VollenIoT.h"

// ─── Credenciais MQTT (embutidas — invisíveis para o usuário final) ─────────
static const char *MQTT_HOST = "k7115118.ala.us-east-1.emqxsl.com";
static const uint16_t MQTT_PORT = 8883;
static const char *MQTT_USER = "volleniot";
static const char *MQTT_PASS = "s4ULdxieG6Rbxu7";

VollenIoT *VollenIoT::_instance = nullptr;

// -----------------------------------------------------------------------------
// Construtor
// -----------------------------------------------------------------------------
VollenIoT::VollenIoT()
    : _mqttPort(MQTT_PORT), _deviceCount(0), _onStateChange(nullptr),
      _lastReconnectAttempt(0), _lastTimerCheck(0), _lastHeartbeat(0),
      _heartbeatInterval(30000) // 30 segundos default
      ,
      _mqttClient(_wifiClient) {
  _instance = this;
  _mqttClient.setCallback(_mqttCallback);
  _mqttClient.setBufferSize(512);

  strncpy(_mqttHost, MQTT_HOST, sizeof(_mqttHost) - 1);
  strncpy(_mqttUser, MQTT_USER, sizeof(_mqttUser) - 1);
  strncpy(_mqttPass, MQTT_PASS, sizeof(_mqttPass) - 1);

  _bootId = 0;
  _duplicateDetected = false;
  _developerMode = false;

  for (uint8_t i = 0; i < MAX_DEVICES; i++) {
    _devices[i].active = false;
    _devices[i].state = false;
    _devices[i].pin = Vollen_NO_PIN;
    _devices[i].id = nullptr;
    _devices[i].name[0] = '\0';
    _devices[i].timerEnd = 0;
    _devices[i].timerAction = false;
    _devices[i].pendingMinutes = 0;
    _devices[i].pendingAction = false;
  }
}

// -----------------------------------------------------------------------------
// Utilitário
// -----------------------------------------------------------------------------
const char *VollenIoT::_deviceLabel(int idx) const {
  return (_devices[idx].name[0] != '\0') ? _devices[idx].name
                                         : _devices[idx].id;
}

// -----------------------------------------------------------------------------
// Gerenciamento de dispositivos
// -----------------------------------------------------------------------------
bool VollenIoT::addDevice(const char *id, const char *name) {
  return _addDeviceInternal(id, name, Vollen_NO_PIN, false);
}

bool VollenIoT::setDevicePin(const char *id, uint8_t pin) {
  int idx = _findDevice(id);
  if (idx < 0) {
    Serial.printf("[VollenIoT] Dispositivo nao encontrado: %s\n", id);
    return false;
  }
  _devices[idx].pin = pin;
  _devices[idx].defaultPin = pin;
  pinMode(pin, OUTPUT);
  bool isInverted = isDeviceCommandInverted(id);
  int pinVal = (_devices[idx].state ^ isInverted) ? HIGH : LOW;
  digitalWrite(pin, pinVal);
  Serial.printf("[VollenIoT] Pino %d associado a %s\n", pin, _deviceLabel(idx));
  return true;
}

bool VollenIoT::setDeviceName(const char *id, const char *name) {
  int idx = _findDevice(id);
  if (idx < 0)
    return false;
  _devices[idx].name[0] = '\0';
  if (name) {
    strncat(_devices[idx].name, name, sizeof(_devices[idx].name) - 1);
  }
  return true;
}

bool VollenIoT::_addDeviceInternal(const char *id, const char *name,
                                   uint8_t pin, bool state) {
  if (_deviceCount >= MAX_DEVICES) {
    Serial.println("[VollenIoT] ERRO: Numero maximo de dispositivos atingido.");
    return false;
  }
  if (_findDevice(id) >= 0) {
    Serial.print("[VollenIoT] Aviso: Dispositivo ja existe: ");
    Serial.println(id);
    return false;
  }
  _devices[_deviceCount].id = strdup(id);
  _devices[_deviceCount].pin = pin;
  _devices[_deviceCount].defaultPin = pin;
  _devices[_deviceCount].state = state;
  _devices[_deviceCount].active = true;
  _devices[_deviceCount].name[0] = '\0';
  _devices[_deviceCount].timerEnd = 0;
  _devices[_deviceCount].timerAction = false;
  _devices[_deviceCount].pendingMinutes = 0;
  _devices[_deviceCount].pendingSeconds = 0;
  _devices[_deviceCount].pendingAction = false;
  strncpy(_devices[_deviceCount].comandoOff, "0",
          sizeof(_devices[_deviceCount].comandoOff) - 1);
  strncpy(_devices[_deviceCount].comandoOn, "1",
          sizeof(_devices[_deviceCount].comandoOn) - 1);
  if (name) {
    strncat(_devices[_deviceCount].name, name,
            sizeof(_devices[_deviceCount].name) - 1);
  }

  if (pin != Vollen_NO_PIN) {
    pinMode(pin, OUTPUT);
    digitalWrite(pin, state ? HIGH : LOW);
  }

  Serial.printf("[VollenIoT] Dispositivo adicionado: %s\n",
                _deviceLabel(_deviceCount));
  _deviceCount++;
  return true;
}

void VollenIoT::removeDevice(const char *id) {
  int idx = _findDevice(id);
  if (idx < 0)
    return;

  if (_devices[idx].id) {
    free(const_cast<char *>(_devices[idx].id));
  }
  for (uint8_t i = idx; i < _deviceCount - 1; i++) {
    _devices[i] = _devices[i + 1];
  }
  _deviceCount--;
  _devices[_deviceCount].active = false;
  _devices[_deviceCount].id = nullptr;
}

bool VollenIoT::setDeviceCommand(const char *id, const char *comandoOff,
                                 const char *comandoOn) {
  int idx = _findDevice(id);
  if (idx < 0) {
    Serial.printf("[VollenIoT] Dispositivo nao encontrado: %s\n", id);
    return false;
  }
  strncpy(_devices[idx].comandoOff, comandoOff,
          sizeof(_devices[idx].comandoOff) - 1);
  strncpy(_devices[idx].comandoOn, comandoOn,
          sizeof(_devices[idx].comandoOn) - 1);
  Serial.printf("%s Comandos: %s (OFF) / %s (ON)\n", _deviceLabel(idx),
                _devices[idx].comandoOff, _devices[idx].comandoOn);
  return true;
}

void VollenIoT::setDeveloperMode(bool enable) {
  _developerMode = enable;
  if (enable) {
    Serial.println(
        "[VollenIoT] Modo Desenvolvedor ATIVADO. Multi-device ID permitido.");
  }
}

int VollenIoT::_findDevice(const char *id) const {
  if (!id) return -1;
  for (uint8_t i = 0; i < _deviceCount; i++) {
    if (_devices[i].active && _devices[i].id && strcasecmp(_devices[i].id, id) == 0) {
      return i;
    }
  }
  return -1;
}

// -----------------------------------------------------------------------------
// Leitura e escrita de estado
// -----------------------------------------------------------------------------
bool VollenIoT::getDeviceState(const char *id) const {
  int idx = _findDevice(id);
  return (idx >= 0) ? _devices[idx].state : false;
}

void VollenIoT::setDeviceState(const char *id, bool newState) {
  int idx = _findDevice(id);
  if (idx < 0)
    return;

  bool mudou = (_devices[idx].state != newState);
  _devices[idx].state = newState;

  if (mudou &&
      (_devices[idx].pendingMinutes > 0 || _devices[idx].pendingSeconds > 0)) {
    if (newState != _devices[idx].pendingAction) {
      unsigned long totalMs =
          ((unsigned long)_devices[idx].pendingMinutes * 60000UL) +
          ((unsigned long)_devices[idx].pendingSeconds * 1000UL);
      _devices[idx].timerEnd = millis() + totalMs;
      _devices[idx].timerAction = _devices[idx].pendingAction;
      Serial.printf("%s Timer iniciado: %d min e %d seg para %s\n",
                    _deviceLabel(idx), _devices[idx].pendingMinutes,
                    _devices[idx].pendingSeconds,
                    _devices[idx].pendingAction ? "Ligar" : "Desligar");
    } else {
      _devices[idx].timerEnd = 0;
      Serial.printf("%s Timer cancelado\n", _deviceLabel(idx));
    }
  }

  if (_devices[idx].pin != Vollen_NO_PIN) {
    bool isInverted = isDeviceCommandInverted(id);
    int pinVal = (newState ^ isInverted) ? HIGH : LOW;
    digitalWrite(_devices[idx].pin, pinVal);
  }
  publishState(id, newState);

  char autoLog[128];
  snprintf(autoLog, sizeof(autoLog), "Estado: %s (Pino: %d)", newState ? "LIGADO [ON]" : "DESLIGADO [OFF]", _devices[idx].pin);
  logSerial(id, autoLog);

  if (_onStateChange) {
    _onStateChange(id, newState);
  }
}

void VollenIoT::toggleDevice(const char *id) {
  int idx = _findDevice(id);
  if (idx < 0)
    return;
  setDeviceState(id, !_devices[idx].state);
}

bool VollenIoT::isDeviceCommandInverted(const char *id) {
  int idx = _findDevice(id);
  if (idx < 0)
    return false;

  // Se comandoOn for "0" ou "OFF" ou "false", é invertido
  if (strcmp(_devices[idx].comandoOn, "0") == 0 ||
      strcasecmp(_devices[idx].comandoOn, "OFF") == 0 ||
      strcasecmp(_devices[idx].comandoOn, "false") == 0) {
    return true;
  }

  int valOn = atoi(_devices[idx].comandoOn);
  int valOff = atoi(_devices[idx].comandoOff);
  if (valOn != 0 || valOff != 0) {
    if (valOn < valOff)
      return true;
  }

  return false;
}

// -----------------------------------------------------------------------------
// Callback
// -----------------------------------------------------------------------------
void VollenIoT::onStateChange(void (*callback)(const char *, bool)) {
  _onStateChange = callback;
}

void VollenIoT::onRawMessage(void (*callback)(const char *, const char *)) {
  _onRawMessage = callback;
}

void VollenIoT::setHeartbeatInterval(unsigned long intervalMs) {
  _heartbeatInterval = intervalMs;
}

// -----------------------------------------------------------------------------
// Ciclo de vida
// -----------------------------------------------------------------------------
void VollenIoT::begin() {
  Serial.println();
  Serial.println("==============================");
  Serial.println("  Vollen IoT - ESP8266");
  Serial.println("==============================");

  randomSeed(ESP.getCycleCount());
  _bootId = random(100000, 999999);

  _setupPins();
  delay(100);
}

void VollenIoT::_setupPins() {
  for (uint8_t i = 0; i < _deviceCount; i++) {
    if (_devices[i].active && _devices[i].pin != Vollen_NO_PIN) {
      pinMode(_devices[i].pin, OUTPUT);
      bool isInverted = isDeviceCommandInverted(_devices[i].id);
      int pinVal = (_devices[i].state ^ isInverted) ? HIGH : LOW;
      digitalWrite(_devices[i].pin, pinVal);
    }
  }
}

void VollenIoT::connect() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println(
        "[VollenIoT] Wi-Fi nao conectado. Chame WiFi.begin() no seu sketch.");
    return;
  }
  _connectMQTT();
}

void VollenIoT::loop() {
  unsigned long agora = millis();
  if (agora - _lastTimerCheck >= 500) {
    _lastTimerCheck = agora;
    _checkTimers();
  }

  // Heartbeat periódico: publica "online" para todos os dispositivos ativos
  if (agora - _lastHeartbeat >= _heartbeatInterval) {
    _lastHeartbeat = agora;
    if (_mqttClient.connected()) {
      for (uint8_t i = 0; i < _deviceCount; i++) {
        if (_devices[i].active) {
          publishStatus(_devices[i].id, "online");
        }
      }
    }
  }

  if (WiFi.status() != WL_CONNECTED)
    return;

  if (!_mqttClient.connected()) {
    if (agora - _lastReconnectAttempt > 5000) {
      _lastReconnectAttempt = agora;
      _connectMQTT();
    }
  } else {
    _mqttClient.loop();
  }
}

void VollenIoT::_checkTimers() {
  unsigned long now = millis();

  // 1. Temporizadores regressivos (ex: desligar em X minutos)
  for (uint8_t i = 0; i < _deviceCount; i++) {
    if (!_devices[i].active || _devices[i].timerEnd == 0)
      continue;
    if (now >= _devices[i].timerEnd) {
      bool alvo = _devices[i].timerAction;
      _devices[i].timerEnd = 0;
      Serial.printf("%s Temporizador: %s\n", _deviceLabel(i),
                    alvo ? "Ligado" : "Desligado");
      setDeviceState(_devices[i].id, alvo);
    }
  }

  // 2. Agendamentos com Dias da Semana (Horário de Brasília)
  time_t tNow = time(nullptr);
  struct tm *tInfo = localtime(&tNow);

  if (tInfo) {
    int curHour = tInfo->tm_hour;
    int curMin = tInfo->tm_min;
    int curWday = tInfo->tm_wday; // 0=Dom, 1=Seg, ..., 6=Sáb

    for (uint8_t i = 0; i < _deviceCount; i++) {
      if (!_devices[i].active) continue;

      for (int s = 0; s < 5; s++) {
        VollenSchedule &sch = _devices[i].schedules[s];
        if (!sch.active) continue;

        bool dayAllowed = (sch.weekDaysMask == 0xFF) || ((sch.weekDaysMask & (1 << curWday)) != 0);

        if (dayAllowed && sch.hour == curHour && sch.minute == curMin) {
          if (!sch.executedThisMinute) {
            sch.executedThisMinute = true;
            Serial.printf("%s Agendamento acionado (%02d:%02d, Dia %d): %s\n",
                          _deviceLabel(i), curHour, curMin, curWday,
                          sch.action ? "LIGADO" : "DESLIGADO");
            setDeviceState(_devices[i].id, sch.action);
          }
        } else {
          sch.executedThisMinute = false;
        }
      }
    }
  }
}

// -----------------------------------------------------------------------------
// MQTT
// -----------------------------------------------------------------------------
void VollenIoT::_connectMQTT() {
  if (_mqttClient.connected())
    return;

  _wifiClient.setInsecure();
  _wifiClient.setTimeout(5);
  _mqttClient.setServer(_mqttHost, _mqttPort);
  _mqttClient.setKeepAlive(15);

  char clientId[32];
  snprintf(clientId, sizeof(clientId), "VollenIoT_ESP_%06X", ESP.getChipId());

  bool conectado = false;
  char willTopic[128] = "";
  if (_deviceCount > 0 && _devices[0].active) {
    snprintf(willTopic, sizeof(willTopic), "%s/status", _devices[0].id);
    conectado = _mqttClient.connect(clientId, _mqttUser, _mqttPass, willTopic,
                                    1, true, "offline");
  } else {
    conectado = _mqttClient.connect(clientId, _mqttUser, _mqttPass);
  }

  if (conectado) {
    Serial.println("[VollenIoT] Dispositivo conectado ao servidor.");
    _duplicateDetected = false;

    // Configura relógio NTP assim que o Wi-Fi obtiver IP e conectar
    configTime(-3 * 3600, 0, "a.st1.ntp.br", "b.st1.ntp.br", "pool.ntp.org");
    Serial.println("[VollenIoT] Relógio NTP sincronizado (UTC-3).");

    publishAllStatus("online");
    logSerialAll("Dispositivo conectado com sucesso ao servidor MQTT Vollen!");

    for (uint8_t i = 0; i < _deviceCount; i++) {
      if (_devices[i].active) {
        _mqttClient.subscribe(_devices[i].id, 1);
        char topicStatus[128];
        snprintf(topicStatus, sizeof(topicStatus), "%s/status", _devices[i].id);
        _mqttClient.subscribe(topicStatus, 1);
        char topicCmd[128];
        snprintf(topicCmd, sizeof(topicCmd), "%s/serial_cmd", _devices[i].id);
        _mqttClient.subscribe(topicCmd, 1);
        char topicOta[128];
        snprintf(topicOta, sizeof(topicOta), "%s/ota_url", _devices[i].id);
        _mqttClient.subscribe(topicOta, 1);
      }
    }
  }
}

// -----------------------------------------------------------------------------
// Publicação
// -----------------------------------------------------------------------------
void VollenIoT::publishStatus(const char *deviceId, const char *status) {
  if (!_mqttClient.connected())
    return;
  char topic[128];
  snprintf(topic, sizeof(topic), "%s/status", deviceId);
  char payload[64];
  if (strcmp(status, "online") == 0) {
    snprintf(payload, sizeof(payload), "online:%lu", _bootId);
  } else {
    snprintf(payload, sizeof(payload), "%s", status);
  }
  _mqttClient.publish(topic, payload, true);
}

void VollenIoT::publishState(const char *deviceId, bool state) {
  if (!_mqttClient.connected())
    return;
  char topic[128];
  snprintf(topic, sizeof(topic), "%s/state", deviceId);
  int idx = _findDevice(deviceId);
  const char *payload = state ? "ON" : "OFF";
  if (idx >= 0) {
    payload = state ? _devices[idx].comandoOn : _devices[idx].comandoOff;
  }
  _mqttClient.publish(topic, payload, true);
}

void VollenIoT::publishRawState(const char *deviceId, const char *rawState) {
  if (!_mqttClient.connected())
    return;
  char topic[128];
  snprintf(topic, sizeof(topic), "%s/state", deviceId);
  _mqttClient.publish(topic, rawState, true);
}

void VollenIoT::publishRaw(const char *topic, const char *payload, bool retained) {
  if (!_mqttClient.connected())
    return;
  _mqttClient.publish(topic, payload, retained);
}

void VollenIoT::publishAllStatus(const char *status) {
  for (uint8_t i = 0; i < _deviceCount; i++) {
    if (_devices[i].active) {
      publishStatus(_devices[i].id, status);
    }
  }
}

void VollenIoT::publishAllState(bool state) {
  for (uint8_t i = 0; i < _deviceCount; i++) {
    if (_devices[i].active) {
      publishState(_devices[i].id, state);
    }
  }
}

void VollenIoT::logSerial(const char *deviceId, const char *message) {
  if (!_mqttClient.connected() || !deviceId || !message)
    return;
  char topic[128];
  snprintf(topic, sizeof(topic), "%s/serial", deviceId);
  _mqttClient.publish(topic, message);
}

void VollenIoT::logSerialAll(const char *message) {
  for (uint8_t i = 0; i < _deviceCount; i++) {
    if (_devices[i].active) {
      logSerial(_devices[i].id, message);
    }
  }
}

// -----------------------------------------------------------------------------
// Status
// -----------------------------------------------------------------------------
bool VollenIoT::isWiFiConnected() const {
  return WiFi.status() == WL_CONNECTED;
}

bool VollenIoT::isMQTTConnected() { return _mqttClient.connected(); }

// -----------------------------------------------------------------------------
// Processamento de mensagens MQTT
// -----------------------------------------------------------------------------
bool VollenIoT::_processMessage(const char *topic, const uint8_t *payload,
                                size_t length) {
  char message[256];
  size_t len = (length < sizeof(message) - 1) ? length : sizeof(message) - 1;
  memcpy(message, payload, len);
  message[len] = '\0';

  // Aparar caracteres de controle e espacos no final da mensagem (evita falha de correspondencia no strcasecmp)
  while (len > 0 && (message[len - 1] == ' ' || message[len - 1] == '\r' || message[len - 1] == '\n' || message[len - 1] == '\t')) {
    message[--len] = '\0';
  }

  char topicLower[128];
  strncpy(topicLower, topic, sizeof(topicLower) - 1);
  topicLower[sizeof(topicLower) - 1] = '\0';
  for (int i = 0; topicLower[i]; i++) {
    topicLower[i] = tolower(topicLower[i]);
  }

  // Verifica se e uma mensagem com subtopico (deviceId/subtopico)
  const char *slash = strchr(topicLower, '/');
  if (slash) {
    char deviceId[128];
    size_t idLen = slash - topicLower;
    if (idLen >= sizeof(deviceId))
      idLen = sizeof(deviceId) - 1;
    memcpy(deviceId, topicLower, idLen);
    deviceId[idLen] = '\0';

    if (strcmp(slash + 1, "status") == 0) {
      int idx = _findDevice(deviceId);
      if (idx >= 0) {
        // Detecta outro dispositivo com o mesmo ID (bootId diferente)
        unsigned long otherBootId;
        if (sscanf(message, "online:%lu", &otherBootId) == 1 &&
            otherBootId != _bootId) {
          if (!_developerMode) {
            Serial.printf("\n[VollenIoT] ERRO: ID duplicado detectado para %s! "
                          "Desconectando do MQTT...\n\n",
                          deviceId);
            _mqttClient.disconnect();
            _duplicateDetected = true;
          } else {
            if (!_duplicateDetected) {
              _duplicateDetected = true;
              Serial.printf("\n*** AVISO: ID duplicado detectado (Modo "
                            "Desenvolvedor Ativo)! ***\n");
              Serial.printf(
                  "*** Dispositivo %s ja esta online em outro ESP ***\n",
                  deviceId);
              Serial.printf(
                  "*** Ambos responderao aos mesmos comandos. ***\n\n");
            }
          }
        }
      }
      return true;
    }

    if (strcmp(slash + 1, "serial_cmd") == 0) {
      char logBuf[256];
      if (strcasecmp(message, "RESTART") == 0 || strcasecmp(message, "RESET") == 0) {
        logSerial(deviceId, "[SYSTEM] Comando de RESTART recebido. Reiniciando placa...");
        publishStatus(deviceId, "offline");
        
        // Executa o loop do MQTT para garantir a entrega das mensagens antes de reiniciar o ESP
        unsigned long startWait = millis();
        while (millis() - startWait < 1200) {
          _mqttClient.loop();
          delay(50);
          yield();
        }
        ESP.restart();
      } else if (strcasecmp(message, "INFO") == 0 || strcasecmp(message, "STATUS") == 0) {
        int devIdx = _findDevice(deviceId);
        const char *stName = (devIdx >= 0 && _devices[devIdx].state) ? "LIGADO" : "DESLIGADO";
        unsigned long upSec = millis() / 1000;
        unsigned long mins = upSec / 60;
        unsigned long hrs = mins / 60;
        char upBuf[32];
        if (hrs > 0) {
          snprintf(upBuf, sizeof(upBuf), "%lu h %lu m", hrs, mins % 60);
        } else if (mins > 0) {
          snprintf(upBuf, sizeof(upBuf), "%lu m %lu s", mins, upSec % 60);
        } else {
          snprintf(upBuf, sizeof(upBuf), "%lu s", upSec);
        }

        snprintf(logBuf, sizeof(logBuf), "[STATUS] Estado: %s | IP: %s | Sinal: %d dBm | RAM: %u B | Uptime: %s",
                 stName, WiFi.localIP().toString().c_str(), WiFi.RSSI(), ESP.getFreeHeap(), upBuf);
        logSerial(deviceId, logBuf);
        publishStatus(deviceId, "online");
        if (devIdx >= 0) {
          publishState(deviceId, _devices[devIdx].state);
        }
      } else if (strcasecmp(message, "MEM") == 0 || strcasecmp(message, "HEAP") == 0 || strcasecmp(message, "FREE_HEAP") == 0) {
        snprintf(logBuf, sizeof(logBuf), "[SYSTEM] Memoria RAM Livre: %u Bytes | RSSI: %d dBm", ESP.getFreeHeap(), WiFi.RSSI());
        logSerial(deviceId, logBuf);
      } else if (strcasecmp(message, "PING") == 0) {
        logSerial(deviceId, "[SYSTEM] PONG! Dispositivo online e operacional.");
        publishStatus(deviceId, "online");
      } else {
        int devIdx = _findDevice(deviceId);
        if (devIdx >= 0) {
          if (strcasecmp(message, "1") == 0 || strcasecmp(message, "ON") == 0 || strcmp(message, _devices[devIdx].comandoOn) == 0) {
            setDeviceState(deviceId, true);
            snprintf(logBuf, sizeof(logBuf), "[SYSTEM] Comando de LIGAR executado via Serial.");
            logSerial(deviceId, logBuf);
          } else if (strcasecmp(message, "0") == 0 || strcasecmp(message, "OFF") == 0 || strcmp(message, _devices[devIdx].comandoOff) == 0) {
            setDeviceState(deviceId, false);
            snprintf(logBuf, sizeof(logBuf), "[SYSTEM] Comando de DESLIGAR executado via Serial.");
            logSerial(deviceId, logBuf);
          } else {
            snprintf(logBuf, sizeof(logBuf), "[SYSTEM] Comando customizado: %s", message);
            logSerial(deviceId, logBuf);
          }
        } else {
          snprintf(logBuf, sizeof(logBuf), "[SYSTEM] Comando customizado: %s", message);
          logSerial(deviceId, logBuf);
        }
      }
      return true;
    }

    if (strcmp(slash + 1, "ota_url") == 0) {
      if (strlen(message) > 5 && (strncmp(message, "http://", 7) == 0 || strncmp(message, "https://", 8) == 0)) {
        char logBuf[256];
        snprintf(logBuf, sizeof(logBuf), "[OTA] Iniciando download da atualizacao: %s", message);
        logSerial(deviceId, logBuf);

        // Configura callbacks de progresso para transmitir porcentagem ao aplicativo
        ESPhttpUpdate.onProgress([this, deviceId](int current, int total) {
          if (total > 0) {
            int pct = (current * 100) / total;
            char pctBuf[16];
            snprintf(pctBuf, sizeof(pctBuf), "%d", pct);
            char otaProgTopic[128];
            snprintf(otaProgTopic, sizeof(otaProgTopic), "%s/ota_progress", deviceId);
            _mqttClient.publish(otaProgTopic, pctBuf, false);
            
            char logBufProgress[128];
            snprintf(logBufProgress, sizeof(logBufProgress), "[OTA] Progresso de gravacao do firmware: %d%% (%d/%d B)", pct, current, total);
            logSerial(deviceId, logBufProgress);
          }
        });

        // Habilita redirecionamento HTTP/HTTPS e segue URLs do Supabase Storage
        ESPhttpUpdate.rebootOnUpdate(true);
        t_httpUpdate_return ret;

        if (strncmp(message, "https://", 8) == 0) {
          WiFiClientSecure otaSecureClient;
          otaSecureClient.setInsecure(); // Permite baixar do Supabase (HTTPS SSL) sem travar no certificado
          ret = ESPhttpUpdate.update(otaSecureClient, message);
        } else {
          WiFiClient otaClient;
          ret = ESPhttpUpdate.update(otaClient, message);
        }

        switch (ret) {
          case HTTP_UPDATE_FAILED:
            snprintf(logBuf, sizeof(logBuf), "[OTA] Falha na Atualizacao (%d): %s", ESPhttpUpdate.getLastError(), ESPhttpUpdate.getLastErrorString().c_str());
            logSerial(deviceId, logBuf);
            break;
          case HTTP_UPDATE_NO_UPDATES:
            logSerial(deviceId, "[OTA] Sem novas atualizacoes no servidor.");
            break;
          case HTTP_UPDATE_OK:
            logSerial(deviceId, "[OTA] Atualizacao concluida com sucesso (100%)! Reiniciando placa...");
            break;
        }
      }
      return true;
    }
  }

  if (message[0] == '{') {
    StaticJsonDocument<768> doc;
    DeserializationError err = deserializeJson(doc, message);
    if (err) {
      Serial.printf("[VollenIoT] Erro JSON: %s\n", err.c_str());
      return false;
    }

    // Processa agendamentos com dias da semana {"schedules": [...]}
    JsonArray schedules = doc["schedules"].as<JsonArray>();
    if (!schedules.isNull()) {
      int idx = _findDevice(topicLower);
      if (idx < 0) idx = _findDevice(topic);

      if (idx >= 0) {
        int count = 0;
        for (JsonObject s : schedules) {
          if (count >= 5) break;
          bool active = s["active"] | true;
          if (!active) continue;

          _devices[idx].schedules[count].active = true;
          _devices[idx].schedules[count].hour = s["hour"] | 0;
          _devices[idx].schedules[count].minute = s["minute"] | 0;
          const char *actStr = s["action"] | "OFF";
          _devices[idx].schedules[count].action = (strcasecmp(actStr, "ON") == 0);

          uint8_t mask = 0;
          if (s.containsKey("days")) {
            JsonArray days = s["days"].as<JsonArray>();
            for (int d : days) {
              if (d >= 0 && d <= 6) mask |= (1 << d);
            }
          } else {
            mask = 0xFF;
          }
          _devices[idx].schedules[count].weekDaysMask = mask;
          _devices[idx].schedules[count].executedThisMinute = false;
          count++;
        }
        for (int i = count; i < 5; i++) {
          _devices[idx].schedules[i].active = false;
        }
        Serial.printf("[VollenIoT] %d Agendamento(s) salvos no dispositivo via MQTT!\n",
                      count);
        return true;
      }
    }

    // Verifica se é configuração dinâmica de comandos
    JsonObject config = doc["config"];
    if (!config.isNull()) {
      const char *cmdOn = config["on"];
      const char *cmdOff = config["off"];
      int idx = _findDevice(topicLower);
      if (idx < 0)
        idx = _findDevice(topic);
      if (idx >= 0) {
        if (cmdOn)
          strncpy(_devices[idx].comandoOn, cmdOn,
                  sizeof(_devices[idx].comandoOn) - 1);
        if (cmdOff)
          strncpy(_devices[idx].comandoOff, cmdOff,
                  sizeof(_devices[idx].comandoOff) - 1);
        if (config.containsKey("pin")) {
          int newPin = config["pin"];
          uint8_t oldPin = _devices[idx].pin;

          if (newPin >= 0) {
            if (oldPin != Vollen_NO_PIN && oldPin != (uint8_t)newPin) {
              bool oldInverted = isDeviceCommandInverted(topic);
              digitalWrite(oldPin, oldInverted ? HIGH : LOW);
              pinMode(oldPin, INPUT);
              Serial.printf("%s Pino antigo GPIO%d desligado e liberado.\n",
                            _deviceLabel(idx), oldPin);
            }
            _devices[idx].pin = (uint8_t)newPin;
            pinMode(_devices[idx].pin, OUTPUT);
            bool isInverted = isDeviceCommandInverted(topic);
            int pinVal = (_devices[idx].state ^ isInverted) ? HIGH : LOW;
            digitalWrite(_devices[idx].pin, pinVal);
            Serial.printf("%s Pino GPIO reconfigurado via MQTT para: GPIO%d\n",
                          _deviceLabel(idx), _devices[idx].pin);
          } else {
            if (oldPin != Vollen_NO_PIN && oldPin != _devices[idx].defaultPin) {
              bool oldInverted = isDeviceCommandInverted(topic);
              digitalWrite(oldPin, oldInverted ? HIGH : LOW);
              pinMode(oldPin, INPUT);
              Serial.printf("%s Pino antigo GPIO%d desligado e liberado.\n",
                            _deviceLabel(idx), oldPin);
            }
            _devices[idx].pin = _devices[idx].defaultPin;
            if (_devices[idx].pin != Vollen_NO_PIN) {
              pinMode(_devices[idx].pin, OUTPUT);
              bool isInverted = isDeviceCommandInverted(topic);
              int pinVal = (_devices[idx].state ^ isInverted) ? HIGH : LOW;
              digitalWrite(_devices[idx].pin, pinVal);
              Serial.printf(
                  "%s Pino GPIO restaurado para o padrao do Sketch: GPIO%d\n",
                  _deviceLabel(idx), _devices[idx].pin);
            } else {
              Serial.printf("%s Pino GPIO redefinido para Padrao (Auto / "
                            "Sketch sem pino associado)\n",
                            _deviceLabel(idx));
            }
          }
        }
        Serial.printf("%s Comandos atualizados via MQTT: %s (OFF) / %s (ON)\n",
                      _deviceLabel(idx), _devices[idx].comandoOff,
                      _devices[idx].comandoOn);
      }
      return true;
    }

    JsonObject timer = doc["timer"];
    if (timer.isNull()) {
      Serial.println("[VollenIoT] JSON recebido sem campo 'timer' ou 'config'");
      return false;
    }

    const char *action = timer["action"];
    int minutes = timer["minutes"] | 0;
    int seconds = timer["seconds"] | 0;

    int idx = _findDevice(topicLower);
    if (idx < 0)
      idx = _findDevice(topic);
    if (idx < 0)
      return false;

    // Cancela timer
    if (minutes <= 0 && seconds <= 0) {
      _devices[idx].timerEnd = 0;
      _devices[idx].pendingMinutes = 0;
      _devices[idx].pendingSeconds = 0;
      Serial.printf("%s Timer cancelado\n", _deviceLabel(idx));
      return true;
    }

    bool alvo = (strcmp(action, "ON") == 0);

    _devices[idx].pendingMinutes = minutes;
    _devices[idx].pendingSeconds = seconds;
    _devices[idx].pendingAction = alvo;

    unsigned long totalMs =
        ((unsigned long)minutes * 60000UL) + ((unsigned long)seconds * 1000UL);

    if (_devices[idx].state != alvo) {
      _devices[idx].timerEnd = millis() + totalMs;
      _devices[idx].timerAction = alvo;
      Serial.printf("%s Temporizador ativo: %d min e %d seg para %s\n",
                    _deviceLabel(idx), minutes, seconds,
                    alvo ? "Ligar" : "Desligar");
    } else {
      _devices[idx].timerEnd = 0;
      Serial.printf("%s Temporizador pendente: %d min e %d seg para %s "
                    "(iniciara assim que o estado mudar para %s)\n",
                    _deviceLabel(idx), minutes, seconds,
                    alvo ? "Ligar" : "Desligar", alvo ? "DESLIGADO" : "LIGADO");
    }
    return true;
  }
  if (_onRawMessage) {
    _onRawMessage(topic, message);
  }

  int idx = _findDevice(topicLower);
  if (idx < 0)
    idx = _findDevice(topic);
  if (idx < 0) {
    return false;
  }

  bool newState = false;
  bool matched = false;

  if (strcmp(message, _devices[idx].comandoOn) == 0) {
    newState = true;
    matched = true;
  } else if (strcmp(message, _devices[idx].comandoOff) == 0) {
    newState = false;
    matched = true;
  }

  if (!matched) {
    return true;
  }

  setDeviceState(_devices[idx].id, newState);
  Serial.printf("%s %s\n", _deviceLabel(idx), newState ? "Ligado" : "Desligado");
  return true;
}

// -----------------------------------------------------------------------------
// Callback MQTT estático
// -----------------------------------------------------------------------------
void VollenIoT::_mqttCallback(char *topic, uint8_t *payload,
                              unsigned int length) {
  if (_instance) {
    _instance->_processMessage(topic, payload, length);
  }
}
